package com.nutritiontracker.NutritionTrackerContactService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutritionTrackerContactServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutritionTrackerContactServiceApplication.class, args);
	}

}
